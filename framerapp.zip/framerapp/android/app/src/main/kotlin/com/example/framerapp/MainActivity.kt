package com.example.framerapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
