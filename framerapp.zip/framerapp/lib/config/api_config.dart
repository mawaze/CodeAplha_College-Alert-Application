final String baseUrl = "https://plant-disease-detection.up.railway.app/auth";
